// scripts/main.js

const targetPlanets = ["serpulo", "erekir"];
let randomSectorButtonAdded = false;

function getRandomAccessibleSector() {
    const sectors = [];

    for (const planetName of targetPlanets) {
        const planet = Vars.content.planet(planetName);
        if (planet == null || planet.sectors == null) continue;

        for (let i = 0; i < planet.sectors.size; i++) {
            const sector = planet.sectors.get(i);
            if (sector != null && sector.unlocked()) {
                sectors.push(sector);
            }
        }
    }

    if (sectors.length === 0) return null;
    return sectors[Math.floor(Math.random() * sectors.length)];
}

function openRandomSector() {
    const sector = getRandomAccessibleSector();

    if (sector == null) {
        Vars.ui.showInfoToast("Нет доступных секторов Серпуло/Эрекир", 3);
        return;
    }

    // Открывает экран выбранного сектора.
    Vars.ui.planet.showSelect(sector, () => {});
}

Events.on(ClientLoadEvent, () => {
    if (randomSectorButtonAdded) return;
    randomSectorButtonAdded = true;

    Core.app.post(() => {
        if (Vars.ui != null && Vars.ui.menufrag != null) {
            Vars.ui.menufrag.addButton("RandomSector", openRandomSector);
        }
    });
});